#!/usr/bin/env bash

#
## Rofi   : Launcher (Modi Drun, Run, File Browser, Window)
#
## Styles
#
## style-1

dir="$HOME/.config/rofi/launchers/type-6"
theme='style-1'

## Run
rofi \
    -show drun \
    -theme $HOME/.config/rofi/launchers/type-6/style-1.rasi
