pkill waybar 

waybar
