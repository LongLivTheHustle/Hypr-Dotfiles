#!/bin/bash

user_string="$USER"

if [ "$user_string" ]; then
    echo "WELCOME BACK, $user_string"
fi